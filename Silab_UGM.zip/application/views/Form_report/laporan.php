<html>
<head>
<style>
*{
    line-height: 1.2;
}
body{
    width: 768px;
    margin: 40px auto;
}
table{
    width: 100%;
    font-size: 14px;
    border-collapse: collapse;
}
table th{
    font-size: 18px;
}
table th, table td{
    padding: 0 5px;
    line-height: 1.5;
}
table thead{
    text-align: center;
}
tbody tr:nth-child(even) {
//   background-color: #f5f5f5;
}

.table-title{
    font-size: 14px;
}
</style>
</head>
<body>